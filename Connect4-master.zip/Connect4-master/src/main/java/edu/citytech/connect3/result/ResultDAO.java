package main.java.edu.citytech.connect3.result;

import main.java.edu.citytech.connect3.jpa.GenericJpaDao;

import javax.persistence.Persistence;
import java.util.List;



public class ResultDAO extends GenericJpaDao<Result> {

    private static ResultDAO instance;

    private ResultDAO() {
        super(Result.class);
    }

    public static ResultDAO getInstance() {
        if (instance == null) {
            instance = new ResultDAO();
            instance.setEntityManager(Persistence.createEntityManagerFactory("persistance-1").createEntityManager());
        }
        return instance;
    }
    public List<Result> findBest(int n) {
        return entityManager.createQuery("SELECT r FROM Result r WHERE r.solved = true ORDER BY r.duration ASC, r.created DESC", Result.class)
                .setMaxResults(n)
                .getResultList();
    }
}
