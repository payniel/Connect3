/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main.java.edu.citytech.connect3.service;

import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * Class made to store some data temporarily.<p>
 *
 * @author ssht
 * @version $Id: $Id
 */
public class Data {

    @Setter
    @Getter
    private static String p1;
    @Setter
    @Getter
    private static String p2;

}
