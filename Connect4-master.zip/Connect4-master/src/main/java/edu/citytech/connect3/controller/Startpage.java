package main.java.edu.citytech.connect3.controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import main.java.edu.citytech.connect3.Connect3Main;

import java.awt.*;
import java.io.IOException;
import java.net.URL;


public class Startpage {

    public void startAction(ActionEvent actionEvent) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(Connect3Main.class.getResource("../../../../resources/fxml/GridPaneConnect3.fxml"));


        Stage stage = new Stage();
        //stage.setScene(new Scene(fxmlLoader.load()));

     /*   URL url = this.getClass().getResource("Connect3.css");
        if (url == null) {
            System.out.println("Resources not found. Aborting...");
            System.exit(-1);        stage.show();

        }

        String css = url.toExternalForm();*/
        stage.setScene(new Scene(fxmlLoader.load()));
        stage.show();
    }
}
