package main.java.edu.citytech.connect3.service;

import com.jbbwebsolutions.connect4.Connect4GradeCalculator;

public class Test {

	public static void main(String[] args) {
		Object o = Connect4GradeCalculator.check(Connect3Service::getWinner, "/Data/Peniel.Oputa");
		System.out.println(o);
	}

}
