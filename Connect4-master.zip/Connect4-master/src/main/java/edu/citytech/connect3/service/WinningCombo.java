package main.java.edu.citytech.connect3.service;

public class WinningCombo {

	public int p1, p2, p3, p4;

	public WinningCombo(int p1, int p2, int p3, int p4) {
		super();
		this.p1 = p1;
		this.p2 = p2;
		this.p3 = p3;
		this.p4 = p4;
	}


}
