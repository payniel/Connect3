package main.java.edu.citytech.connect3;

import java.net.URL;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Connect3Main extends Application {

	public static void main(String[] args) {
		Application.launch(Connect3Main.class, args);
	}

	@Override
	public void start(Stage stage) throws Exception {
		/*Parent root = FXMLLoader.load(getClass().getResource("../../../../resources/fxml/Startpage.fxml"));
		stage.setTitle("Connect 3");

		Scene scene = new Scene (root);
		stage.setScene(scene);

		URL url = this.getClass().getResource("Connect3.css");
		if (url == null) {
			System.out.println("Resources not found. Aborting...");
			System.exit(-1);
		}

		String css = url.toExternalForm();
		scene.getStylesheets().add(css);
		stage.show();
*/
		FXMLLoader loader = new FXMLLoader(Connect3Main.class.getResource("../../../../resources/fxml/Startpage.fxml"));
		Scene scene = new Scene(loader.load());
		//this.mainStage = stage;
		stage.setTitle("Chess Knights");
		stage.setResizable(false);
		//stage.setOnCloseRequest(FunctionsLib.confirmCloseEventHandler);
		stage.setScene(scene);
		stage.show();
		//log.info("Showing the Main Scene of Game");
	}

}
