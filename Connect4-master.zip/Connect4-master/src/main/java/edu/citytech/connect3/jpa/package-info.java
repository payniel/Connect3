/**
 * Provides helper classes to work with JPA.
 */
package main.java.edu.citytech.connect3.jpa;
